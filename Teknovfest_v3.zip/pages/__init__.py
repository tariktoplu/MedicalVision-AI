# pages/__init__.py

from .start_page import StartPage
from .analysis_mode_page import AnalysisModePage
from .single_analysis_page import SingleAnalysisPage
from .multi_analysis_page import MultiAnalysisPage